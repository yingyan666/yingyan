// 购物车管理类
class ShoppingCart {
    constructor() {
        this.items = this.loadCartFromStorage();
        
        // 只在购物车页面执行渲染和订单摘要更新
        if (window.location.pathname.includes('shopcar.html') || window.location.pathname.endsWith('shopcar.html')) {
            this.renderCartItems();
            this.updateOrderSummary();
        }
        
        this.updateCartCount();
    }

    // 从本地存储加载购物车
    loadCartFromStorage() {
        const cartData = localStorage.getItem('apple_cart');
        return cartData ? JSON.parse(cartData) : [];
    }

    // 保存购物车到本地存储
    saveCartToStorage() {
        localStorage.setItem('apple_cart', JSON.stringify(this.items));
    }

    // 渲染购物车商品列表
    renderCartItems() {
        const cartItemsList = document.getElementById('cart-items-list');
        const emptyCart = document.getElementById('empty-cart');
        
        // 清空当前列表
        cartItemsList.innerHTML = '';
        
        if (this.items.length === 0) {
            // 显示空购物车状态
            emptyCart.style.display = 'block';
        } else {
            // 隐藏空购物车状态
            emptyCart.style.display = 'none';
            
            // 渲染商品列表
            this.items.forEach(item => {
                const itemElement = this.createCartItemElement(item);
                cartItemsList.appendChild(itemElement);
            });
        }
        
        // 更新结算按钮状态
        this.updateCheckoutButton();
    }

    // 创建购物车商品元素
    createCartItemElement(item) {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'cart-item';
        itemDiv.dataset.id = item.id;
        
        itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="item-img">
            <div class="item-info">
                <div class="item-name">${item.name}</div>
                <div class="item-spec">颜色：${item.color} | 容量：${item.capacity}</div>
                <div class="item-remove">移除</div>
            </div>
            <div class="item-quantity">
                <button class="qty-btn decrease-btn">-</button>
                <input type="number" class="qty-input" value="${item.quantity}" min="1">
                <button class="qty-btn increase-btn">+</button>
            </div>
            <div class="item-price">¥${item.price}</div>
        `;
        
        // 获取元素并绑定事件监听器
        const decreaseBtn = itemDiv.querySelector('.decrease-btn');
        const increaseBtn = itemDiv.querySelector('.increase-btn');
        const qtyInput = itemDiv.querySelector('.qty-input');
        const removeBtn = itemDiv.querySelector('.item-remove');
        
        // 绑定事件
        decreaseBtn.addEventListener('click', () => this.decreaseQuantity(item.id));
        increaseBtn.addEventListener('click', () => this.increaseQuantity(item.id));
        qtyInput.addEventListener('change', (e) => this.updateQuantity(item.id, e.target.value));
        removeBtn.addEventListener('click', () => this.removeItem(item.id));
        
        return itemDiv;
    }

    // 增加商品数量
    increaseQuantity(itemId) {
        const item = this.items.find(item => item.id === itemId);
        if (item) {
            item.quantity += 1;
            this.saveCartToStorage();
            this.renderCartItems();
            this.updateOrderSummary();
        }
    }

    // 减少商品数量
    decreaseQuantity(itemId) {
        const itemIndex = this.items.findIndex(item => item.id === itemId);
        if (itemIndex !== -1) {
            if (this.items[itemIndex].quantity > 1) {
                this.items[itemIndex].quantity -= 1;
            } else {
                this.removeItem(itemId);
                return;
            }
            this.saveCartToStorage();
            this.renderCartItems();
            this.updateOrderSummary();
        }
    }

    // 更新商品数量
    updateQuantity(itemId, quantity) {
        const item = this.items.find(item => item.id === itemId);
        if (item) {
            const newQuantity = Math.max(1, parseInt(quantity) || 1);
            item.quantity = newQuantity;
            this.saveCartToStorage();
            this.renderCartItems();
            this.updateOrderSummary();
        }
    }

    // 移除商品
    removeItem(itemId) {
        this.items = this.items.filter(item => item.id !== itemId);
        this.saveCartToStorage();
        this.renderCartItems();
        this.updateOrderSummary();
        this.updateCartCount();
    }

    // 更新订单摘要
    updateOrderSummary() {
        const subtotal = this.calculateSubtotal();
        const tax = this.calculateTax(subtotal);
        const total = subtotal + tax;
        
        document.getElementById('subtotal').textContent = `¥${subtotal}`;
        document.getElementById('tax').textContent = `¥${tax}`;
        document.getElementById('total').textContent = `¥${total}`;
    }

    // 计算商品小计
    calculateSubtotal() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    // 计算税费（假设税率为13%）
    calculateTax(subtotal) {
        return Math.round(subtotal * 0.13);
    }

    // 更新结算按钮状态
    updateCheckoutButton() {
        const checkoutBtn = document.getElementById('checkout-btn');
        checkoutBtn.disabled = this.items.length === 0;
    }

    // 更新购物车数量显示
    updateCartCount() {
        const cartCount = document.getElementById('cart-count');
        if (!cartCount) return;
        
        const totalItems = this.items.reduce((total, item) => total + item.quantity, 0);
        cartCount.textContent = totalItems;
        
        // 如果没有商品，隐藏数量显示
        if (totalItems === 0) {
            cartCount.style.display = 'none';
        } else {
            cartCount.style.display = 'flex';
        }
    }

    // 添加商品到购物车
    addToCart(product) {
        const existingItemIndex = this.items.findIndex(item => 
            item.name === product.name && 
            item.color === product.color && 
            item.capacity === product.capacity
        );
        
        if (existingItemIndex !== -1) {
            // 如果商品已存在，增加数量
            this.items[existingItemIndex].quantity += 1;
        } else {
            // 如果商品不存在，添加新商品
            const newItem = {
                ...product,
                quantity: 1,
                id: Date.now().toString()
            };
            this.items.push(newItem);
        }
        
        // 保存到本地存储
        this.saveCartToStorage();
        
        // 更新购物车数量显示
        this.updateCartCount();
        
        return true;
    }
}

// 页面加载完成后初始化购物车
let cart;
document.addEventListener('DOMContentLoaded', function() {
    cart = new ShoppingCart();
});
